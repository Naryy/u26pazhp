<?php
$dsn      = 'mysql:dbname=AEON;host=localhost';
$user     = 'root';
$password = 'root';
?>